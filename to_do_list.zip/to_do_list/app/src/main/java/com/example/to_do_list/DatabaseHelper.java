package com.example.to_do_list;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Nom de la base de données
    private static final String DATABASE_NAME = "to_do_list.db";
    private static final int DATABASE_VERSION = 1;

    // Nom des tables et des colonnes
    public static final String TABLE_TASKS = "tache";
    public static final String COLUMN_TASK_ID = "id";
    public static final String COLUMN_TASK_TITLE = "title";
    public static final String COLUMN_TASK_DESCRIPTION = "description";
    public static final String COLUMN_TASK_HEURE = "heure";
    public static final String COLUMN_TASK_EST_TERMINEE = "est_terminee";
    public static final String COLUMN_TASK_DATE_CREATION = "date_creation";
    public static final String COLUMN_TASK_DATE_MODIFICATION = "date_modification";
    public static final String COLUMN_TASK_DATE_TACHE = "date_tache";
    public static final String COLUMN_TASK_RAPPEL1 = "rappel_avant_debut";
    public static final String COLUMN_TASK_RAPPEL2 = "rappel_retard";
    public static final String COLUMN_TASK_PRIORITE = "priorite";
    public static final String COLUMN_TASK_RECURRENCE = "recurrence";
    public static final String COLUMN_TASK_CATEGORIE = "categorie";

    public static final String TABLE_USER = "utilisateur";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USER_NAME = "name";
    public static final String COLUMN_USER_EMAIL = "email";
    public static final String COLUMN_USER_PASSWORD = "password";

    public static final String TABLE_SOUS_TACHE = "sous_tache";
    public static final String COLUMN_SOUS_TACHE_ID = "id";
    public static final String COLUMN_SOUS_TACHE_TITRE = "titre";
    public static final String COLUMN_SOUS_TACHE_DESCRIPTION = "description";
    public static final String COLUMN_SOUS_TACHE_EST_TERMINEE = "est_terminee";
    public static final String COLUMN_SOUS_TACHE_TASK_ID = "task_id";

    public static final String TABLE_PRIORITE = "priorite";
    public static final String COLUMN_PRIORITE_ID = "id";
    public static final String COLUMN_PRIORITE_TITRE = "titre";
    public static final String COLUMN_PRIORITE_DESCRIPTION = "description";
    public static final String COLUMN_PRIORITE_EST_TERMINEE = "est_terminee";

    public static final String TABLE_RECURRENCE = "recurrence";
    public static final String COLUMN_RECURRENCE_ID = "id";
    public static final String COLUMN_RECURRENCE_NAME = "name";
    public static final String COLUMN_RECURRENCE_DESCRIPTION = "description";

    public static final String TABLE_CATEGORIE = "categorie";
    public static final String COLUMN_CATEGORIE_ID = "id";
    public static final String COLUMN_CATEGORIE_NAME = "name";
    public static final String COLUMN_CATEGORIE_DESCRIPTION = "description";

    private static final String CREATE_TABLE_TASKS = "CREATE TABLE " + TABLE_TASKS + " ("
            + COLUMN_TASK_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_TASK_TITLE + " TEXT NOT NULL, "
            + COLUMN_TASK_DESCRIPTION + " TEXT, "
            + COLUMN_TASK_HEURE + " TEXT, "
            + COLUMN_TASK_EST_TERMINEE + " INTEGER, "
            + COLUMN_TASK_DATE_CREATION + " TEXT, "
            + COLUMN_TASK_DATE_MODIFICATION + " TEXT, "
            + COLUMN_TASK_DATE_TACHE + " TEXT, "
            + COLUMN_TASK_RAPPEL1 + " INTEGER, "
            + COLUMN_TASK_RAPPEL2 + " INTEGER, "
            + COLUMN_TASK_PRIORITE + " INTEGER, "
            + COLUMN_TASK_RECURRENCE + " INTEGER, "
            + COLUMN_TASK_CATEGORIE + " INTEGER, "
            + "FOREIGN KEY(" + COLUMN_TASK_PRIORITE + ") REFERENCES " + TABLE_PRIORITE + "(" + COLUMN_PRIORITE_ID + "), "
            + "FOREIGN KEY(" + COLUMN_TASK_RECURRENCE + ") REFERENCES " + TABLE_RECURRENCE + "(" + COLUMN_RECURRENCE_ID + "), "
            + "FOREIGN KEY(" + COLUMN_TASK_CATEGORIE + ") REFERENCES " + TABLE_CATEGORIE + "(" + COLUMN_CATEGORIE_ID + ")"
            + ");";

    private static final String CREATE_TABLE_SOUS_TACHE = "CREATE TABLE " + TABLE_SOUS_TACHE + " ("
            + COLUMN_SOUS_TACHE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_SOUS_TACHE_TITRE + " TEXT NOT NULL, "
            + COLUMN_SOUS_TACHE_DESCRIPTION + " TEXT, "
            + COLUMN_SOUS_TACHE_EST_TERMINEE + " INTEGER, "
            + COLUMN_SOUS_TACHE_TASK_ID + " INTEGER, "
            + "FOREIGN KEY(" + COLUMN_SOUS_TACHE_TASK_ID + ") REFERENCES " + TABLE_TASKS + "(" + COLUMN_TASK_ID + ") ON DELETE CASCADE"
            + ");";

    private static final String CREATE_TABLE_USER = "CREATE TABLE " + TABLE_USER + " ("
            + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_USER_NAME + " TEXT NOT NULL, "
            + COLUMN_USER_EMAIL + " TEXT NOT NULL, "
            + COLUMN_USER_PASSWORD + " TEXT NOT NULL"
            + ");";

    private static final String CREATE_TABLE_PRIORITE = "CREATE TABLE " + TABLE_PRIORITE + " ("
            + COLUMN_PRIORITE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_PRIORITE_TITRE + " TEXT NOT NULL, "
            + COLUMN_PRIORITE_DESCRIPTION + " TEXT, "
            + COLUMN_PRIORITE_EST_TERMINEE + " INTEGER"
            + ");";

    private static final String CREATE_TABLE_RECURRENCE = "CREATE TABLE " + TABLE_RECURRENCE + " ("
            + COLUMN_RECURRENCE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_RECURRENCE_NAME + " TEXT NOT NULL, "
            + COLUMN_RECURRENCE_DESCRIPTION + " TEXT"
            + ");";

    private static final String CREATE_TABLE_CATEGORIE = "CREATE TABLE " + TABLE_CATEGORIE + " ("
            + COLUMN_CATEGORIE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_CATEGORIE_NAME + " TEXT NOT NULL, "
            + COLUMN_CATEGORIE_DESCRIPTION + " TEXT"
            + ");";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("PRAGMA foreign_keys = ON;");  // Active les clés étrangères
        db.execSQL(CREATE_TABLE_TASKS);
        db.execSQL(CREATE_TABLE_USER);
        db.execSQL(CREATE_TABLE_SOUS_TACHE);
        db.execSQL(CREATE_TABLE_PRIORITE);
        db.execSQL(CREATE_TABLE_RECURRENCE);
        db.execSQL(CREATE_TABLE_CATEGORIE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TASKS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SOUS_TACHE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PRIORITE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RECURRENCE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CATEGORIE);
        onCreate(db);
    }
}
