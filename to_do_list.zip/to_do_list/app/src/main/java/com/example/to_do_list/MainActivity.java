package com.example.to_do_list;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // tu peux même le retirer si tu veux

        // Juste pour déclencher la création de la base de données
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        dbHelper.getWritableDatabase(); // crée la base et les tables si elles n'existent pas encore
    }
}